-- Provisioned remote status terminal. Flight/engineering commands are added separately.
local function readJSON(path)
    local h=assert(fs.open(path,"r"),"Remote configuration missing");local data=h.readAll();h.close()
    return assert(textutils.unserializeJSON(data),"Invalid remote configuration")
end
local cfg=readJSON("/amaryllis-remote.json")
assert(cfg.schemaVersion==1 and type(cfg.coreID)=="number" and type(cfg.token)=="string" and
    type(cfg.pairID)=="string" and cfg.protocol=="amaryllis.remote.v1","Invalid remote pairing")
local pages={"OVERVIEW","FLEET","LIFT","PROPULSION","NAVIGATION","LOGS"}
local page,scroll=1,0
local lines={"Connecting to Amaryllis..."};local issue,boot,coreLabel=nil,nil,"AMARYLLIS"
local pending,pendingPage,timeout,refresh;local sequence=0
local online=false
local function text(value) return tostring(value or ""):gsub("[%c]"," ") end
local function modems()
    local found=false
    for _,name in ipairs(peripheral.getNames()) do
        if peripheral.hasType(name,"modem") then
            local modem=peripheral.wrap(name);local ok,wireless=pcall(modem.isWireless)
            if ok and wireless then rednet.open(name);found=true end
        end
    end
    return found
end
local function request()
    if not modems() then issue="Attach a wireless modem upgrade";online=false;return end
    sequence=sequence+1
    pending=tostring(os.getComputerID())..":"..os.epoch("utc")..":"..sequence
    pendingPage=pages[page]
    rednet.send(cfg.coreID,{v=1,pairID=cfg.pairID,token=cfg.token,requestID=pending,
        action=boot and "status" or "hello",page=pages[page],boot=boot,sentAt=os.epoch("utc")},cfg.protocol)
    timeout=os.startTimer(5)
end
local function draw()
    local width,height=term.getSize();term.setBackgroundColor(colors.black);term.setTextColor(colors.white);term.clear()
    local function row(y,s,color)
        if y>=1 and y<=height then term.setCursorPos(1,y);term.setTextColor(color or colors.white);term.write(text(s):sub(1,width)) end
    end
    row(1,"AMARYLLIS / REMOTE",colors.cyan)
    row(2,(online and "CONNECTED " or "OFFLINE ").."#"..cfg.coreID,online and colors.lime or colors.yellow)
    row(3,"< "..pages[page].." >",colors.cyan)
    local body=math.max(1,height-6);local wrapped={}
    for _,line in ipairs(lines) do
        line=text(line)
        if line=="" then wrapped[#wrapped+1]="" end
        for start=1,#line,math.max(1,width) do wrapped[#wrapped+1]=line:sub(start,start+width-1) end
    end
    scroll=math.min(scroll,math.max(0,#wrapped-body))
    for i=1,body do row(i+3,wrapped[i+scroll] or "",online and colors.white or colors.gray) end
    row(height-2,issue or coreLabel,issue and colors.yellow or colors.gray)
    row(height-1,"P:AP  Arrows:page/scroll",colors.gray)
    local legacy=fs.exists("/admin.lua") and " A:admin" or (fs.exists("/remote/original-startup.lua") and " O:original" or "")
    row(height,"R:refresh Q:exit"..legacy,colors.gray)
end
request();refresh=os.startTimer(2);draw()
while true do
    local event,a,b,c=os.pullEvent()
    if event=="rednet_message" and a==cfg.coreID and c==cfg.protocol and type(b)=="table" and b.v==1 and
        b.requestID==pending and b.coreID==cfg.coreID and type(b.boot)=="string" then
        os.cancelTimer(timeout);pending=nil
        if b.ok then
            online=true;issue=nil
            if not boot then boot=b.boot;coreLabel=text((b.data or {}).label or "Amaryllis");request()
            elseif b.boot~=boot then boot=nil;online=false;issue="Core restarted; reconnecting"
            elseif pendingPage==pages[page] and type(b.data)=="table" and type(b.data.lines)=="table" then
                lines={};for i=1,math.min(40,#b.data.lines) do lines[i]=text(b.data.lines[i]):sub(1,140) end
            end
        else
            online=false;issue=text(b.error or "Request rejected")
            if issue:find("reconnect",1,true) then boot=nil end
        end
    elseif event=="timer" and a==timeout and pending then
        pending=nil;boot=nil;online=false;issue="STALE: core is not replying"
    elseif event=="timer" and a==refresh then
        refresh=os.startTimer(2);if not pending then request() end
    elseif event=="key" then
        if a==keys.left or a==keys.right then
            page=(page-1+(a==keys.right and 1 or -1))%#pages+1;scroll=0
            lines={"Waiting for "..pages[page].." readings..."}
        elseif a==keys.up then scroll=math.max(0,scroll-1)
        elseif a==keys.down then scroll=scroll+1 end
    elseif event=="mouse_scroll" then scroll=math.max(0,scroll+a)
    elseif event=="char" then
        if a=="q" then return
        elseif a=="r" and not pending then request()
        elseif a=="p" or (a=="a" and fs.exists("/admin.lua")) or (a=="o" and fs.exists("/remote/original-startup.lua")) then
            local path=a=="p" and fs.combine(fs.getDir(shell.getRunningProgram()),"ops.lua") or
                (a=="a" and "/admin.lua" or "/remote/original-startup.lua")
            shell.run(path)
            -- The other program may have consumed our timer events while foregrounded.
            if timeout then os.cancelTimer(timeout) end
            os.cancelTimer(refresh);pending=nil;boot=nil;online=false
            request();refresh=os.startTimer(2)
        end
    elseif event=="peripheral" then if not pending then request() end end
    draw()
end
