-- Installer-owned display. Reads cached transfer state; never touches hardware.
local Progress={}
Progress.__index=Progress
local labels={starting="Starting installer",waiting_for_modem="Opening wireless modem",
    no_modem="No wireless modem; retrying",waiting_for_client="Waiting for computers",
    offered="Waiting for computer to accept",transferring="Sending package files",
    committing="Verifying and committing package",installed="Package installed",
    current="Package is up to date",transfer_failed="Transfer failed; will retry",
    configuration_error="Installer configuration error",fleet_registry_error="Fleet registration error",
    rejected_hello="Computer identity rejected",bundle_error="Package could not be prepared",
    checking="Checking package files (paced)",paused="Installer paused; flight workers continue"}
local rowStates={checking="CHECK",offered="OFFER",transferring="SEND",committing="VERIFY",
    installed="DONE",current="DONE",transfer_failed="FAULT",bundle_error="FAULT"}
local function clean(value) return tostring(value or ""):gsub("[%c]"," ") end
local function finite(value) return type(value)=="number" and value==value and value~=math.huge and value~=-math.huge end
function Progress.new(screen,now)
    return setmetatable({screen=screen,now=now,rows={},order={},lastDraw=-math.huge},Progress)
end
function Progress:setFleet(fleet,roleFiles)
    local rows,order={},{}
    for role,entry in pairs(fleet and fleet.computers or {}) do
        if roleFiles[role] and type(entry)=="table" and type(entry.id)=="number" then
            local old=self.rows[role]
            rows[role]=old and old.id==entry.id and old.label==entry.label and old or
                {id=entry.id,label=entry.label,role=role,state="WAIT"}
            order[#order+1]=role
        end
    end
    table.sort(order,function(a,b) return rows[a].id<rows[b].id end)
    self.rows,self.order=rows,order
end
function Progress:update(status)
    if status.coreSession and self.coreSession and status.coreSession~=self.coreSession then
        for _,row in pairs(self.rows) do row.state="WAIT";row.reason=nil end
    end
    self.coreSession=status.coreSession or self.coreSession
    local row=self.rows[status.targetRole]
    if row and row.id==status.targetID then
        local state=rowStates[status.state]
        if state then row.state=state;row.reason=state=="FAULT" and clean(status.lastError) or nil end
        if status.state=="paused" and row.state~="DONE" then row.state="WAIT";row.reason=nil end
    end
    if status.requestID~=self.requestID then
        self.requestID=status.requestID;self.retryBase=status.retries or 0
    end
end
function Progress:frame(status,width,height)
    local lines,tones={},{}
    local function line(y,text,tone) if y>=1 and y<=height then lines[y]=clean(text):sub(1,width);tones[y]=tone end end
    local installed,failed=0,0
    for _,row in pairs(self.rows) do
        if row.state=="DONE" then installed=installed+1 elseif row.state=="FAULT" then failed=failed+1 end
    end
    line(1,"AMARYLLIS / PACKAGE INSTALLER","cyan")
    line(2,string.format("Installed %d/%d   Pending %d   Failed %d",installed,#self.order,#self.order-installed,failed))
    local current=self.rows[status.targetRole]
    line(3,current and string.format("#%d  %s",current.id,current.role) or "Waiting for assigned computers")
    local state=labels[status.state] or clean(status.state):gsub("_"," ")
    local fault=status.state=="transfer_failed" or status.state=="bundle_error" or status.state=="configuration_error" or status.state=="fleet_registry_error"
    line(4,state,fault and "red" or (status.state=="installed" or status.state=="current") and "lime" or "yellow")
    local active=status.state=="transferring" or status.state=="committing" or status.state=="offered"
    local total=finite(status.bytesTotal) and math.max(0,status.bytesTotal) or 0
    local sent=active and finite(status.bytesSent) and math.max(0,math.min(total,status.bytesSent)) or 0
    if status.state=="installed" or status.state=="current" then sent=total end
    local fraction=total>0 and sent/total or 0
    local file=clean(status.currentPath):match("([^/]+)$") or ""
    if active then
        line(5,string.format("File %d/%d%s",status.fileIndex or 0,status.filesTotal or 0,file~="" and (": "..file) or ""))
        local bar=math.max(1,width-9);local filled=math.floor(bar*fraction)
        line(6,"["..string.rep("#",filled)..string.rep(".",bar-filled).."] "..string.format("%3d%%",math.floor(fraction*100)),"cyan")
        line(7,string.format("%.1f / %.1f KiB   Retries %d",sent/1024,total/1024,math.max(0,(status.retries or 0)-(self.retryBase or 0))))
    end
    line(8,fault and clean(status.lastError) or "DONE = package installed; hardware checked separately",fault and "red" or "lightGray")
    if status.state=="paused" then line(8,"Paused by /installer/paused; remove file to resume","yellow") end
    if status.state=="checking" then line(5,"Initial/changed files; controls keep their turn","lightGray") end
    local cols=width>=46 and 2 or 1
    local count=math.max(0,height-10);local capacity=count*cols
    local start=1
    if capacity>0 and #self.order>capacity then
        start=(math.floor(self.now()/8)%math.ceil(#self.order/capacity))*capacity+1
    end
    local cells={}
    for i=start,math.min(#self.order,start+capacity-1) do
        local n=i-start;local col=math.floor(n/math.max(1,count));local y=10+(n%math.max(1,count))
        local row=self.rows[self.order[i]];local cellWidth=math.floor(width/cols)
        local stateWidth=6;local prefix=string.format("#%d %s",row.id,row.role):sub(1,math.max(1,cellWidth-stateWidth-1))
        cells[#cells+1]={x=col*cellWidth+1,y=y,label=prefix,state=row.state,width=cellWidth,
            tone=row.state=="DONE" and "lime" or row.state=="FAULT" and "red" or row.state=="WAIT" and "lightGray" or "yellow"}
    end
    line(9,"COMPUTERS","cyan")
    line(height,#self.order>capacity and capacity>0 and "More computers shown every 8 seconds" or "Waiting computers will connect automatically","lightGray")
    return {lines=lines,tones=tones,cells=cells,installed=installed,total=#self.order,failed=failed}
end
function Progress:draw(status,force)
    local now=self.now()
    if not force and now-self.lastDraw<0.25 then return end
    local screen=self.screen;local width,height=screen.getSize()
    local frame=self:frame(status,width,height)
    local parts={tostring(width),tostring(height)}
    for y=1,height do parts[#parts+1]=(frame.lines[y] or "")..":"..(frame.tones[y] or "") end
    for _,cell in ipairs(frame.cells) do parts[#parts+1]=cell.label..cell.state..cell.tone end
    local signature=table.concat(parts,"|")
    if not force and signature==self.signature then return end
    self.lastDraw,self.signature=now,signature
    local palette={white=1,lime=32,yellow=16,red=16384,cyan=512,lightGray=256,black=32768}
    if screen.setBackgroundColor then screen.setBackgroundColor(palette.black) end
    for y=1,height do
        screen.setCursorPos(1,y)
        if screen.setTextColor then screen.setTextColor(palette[frame.tones[y] or "white"]) end
        screen.write(string.rep(" ",width));screen.setCursorPos(1,y);screen.write(frame.lines[y] or "")
    end
    for _,cell in ipairs(frame.cells) do
        screen.setCursorPos(cell.x,cell.y)
        if screen.setTextColor then screen.setTextColor(palette.white) end
        screen.write(cell.label)
        screen.setCursorPos(cell.x+cell.width-#cell.state,cell.y)
        if screen.setTextColor then screen.setTextColor(palette[cell.tone]) end
        screen.write(cell.state)
    end
    if screen.setTextColor then screen.setTextColor(palette.white) end
    screen.setCursorPos(1,height)
end
return Progress
